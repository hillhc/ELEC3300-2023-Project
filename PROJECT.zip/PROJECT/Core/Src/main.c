/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "lcdtp.h"
#include "stdio.h"
#include "xpt2046.h"
#include <string.h>
#include "DFPLAYER_MINI.h"
#define DHT11_PORT GPIOA
#define DHT11_PIN GPIO_PIN_3
uint8_t hum1,hum2,temp1,temp2,check;
float display_temp = 0;
float display_hum = 0;
int status = 0;
//for player
int flaging = 0;
int first = 1;
#define Play_start_port GPIOA
#define Play_start_pin GPIO_PIN_5
//for UI
int UI_Page = 0;
//for wifi
#include "cJSON.h"
#define WIFI_SSID "Hill"
#define WIFI_PASSWORD "S141028a"
#define NEWS_API_KEY "e5f19bf7a2e945aaba86f280b55351be"
#define NEWS_IP "43.225.10.196"
#define NEW_PORT "3000"
#define TIME_IP "worldtimeapi.org"
#define TIME_PORT "80"

const char* AT_COMMAND_CHECK = "AT\r\n"; //Check connection between the board and the esp 8266
const char* AT_COMMAND_RESET = "AT+RST\r\n"; // Reset ESP8266 module
const char* AT_COMMAND_CWMODE = "AT+CWMODE=1\r\n"; // 1 = Station mode (STA)
const char* AT_COMMAND_SINGLE = "AT+CIPMUX=0\r\n"; //Set ESP8266 to single connection mode
const char* AT_COMMAND_CIPSTART = "AT+CIPSTART=\"TCP\",\""; // Establish TCP connection with targerted server.
const char* AT_COMMAND_SETMODE = "AT+CIPMODE=1\r\n"; //Set to transmit mode
const char* AT_COMMAND_CIPSEND = "AT+CIPSEND="; // Send data
const char* AT_COMMAND_CLOSE = "AT+CIPCLOSE\r\n";   // Close TCP connection
const char* AT_DHCP ="AT+CWDHCP=1,0\r\n";

#define MAX_BUFFER_SIZE 2048
extern UART_HandleTypeDef huart3;
#define ESP8266_UART &huart3
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
 I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim6;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart3;

SRAM_HandleTypeDef hsram1;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM6_Init(void);
static void MX_FSMC_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */
const uint8_t Prev[] =
{
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x02, 0x00, 0x60, 0x06, 0x00, 0xe0, 0x0e, 0x01, 0xe0, 0x1e, 0x03, 0xe0, 0x3e, 0x07, 0xe0, 0x7e, 0x0f, 0xe0, 0xfe, 0x1f, 0xe1, 0xfe, 0x3f, 0xe3, 0xfe, 0x7f, 0xe7, 0xfe, 0x7f, 0xe7, 0xfe, 0x3f, 0xe3, 0xfe, 0x1f, 0xe1, 0xfe, 0x0f, 0xe0, 0xfe, 0x07, 0xe0, 0x7e, 0x03, 0xe0, 0x3e, 0x01, 0xe0, 0x1e, 0x00, 0xe0, 0x0e, 0x00, 0x60, 0x06, 0x00, 0x20, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

const uint8_t Pause[] =
{
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0xe7, 0xc0, 0x03, 0xe7, 0xc0, 0x03, 0xe7, 0xc0, 0x03, 0xe7, 0xc0, 0x03, 0xe7, 0xc0, 0x03, 0xe7, 0xc0, 0x03, 0xe7, 0xc0, 0x03, 0xe7, 0xc0, 0x03, 0xe7, 0xc0, 0x03, 0xe7, 0xc0, 0x03, 0xe7, 0xc0, 0x03, 0xe7, 0xc0, 0x03, 0xe7, 0xc0, 0x03, 0xe7, 0xc0, 0x03, 0xe7, 0xc0, 0x03, 0xe7, 0xc0, 0x03, 0xe7, 0xc0, 0x03, 0xe7, 0xc0, 0x03, 0xe7, 0xc0, 0x03, 0xe7, 0xc0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

const uint8_t Next[] =	//big endian row major 24 by 24
{
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x04, 0x00, 0x60, 0x06, 0x00, 0x70, 0x07, 0x00, 0x78, 0x07, 0x80, 0x7c, 0x07, 0xc0, 0x7e, 0x07, 0xe0, 0x7f, 0x07, 0xf0, 0x7f, 0x87, 0xf8, 0x7f, 0xc7, 0xfc, 0x7f, 0xe7, 0xfe, 0x7f, 0xe7, 0xfe, 0x7f, 0xc7, 0xfc, 0x7f, 0x87, 0xf8, 0x7f, 0x07, 0xf0, 0x7e, 0x07, 0xe0, 0x7c, 0x07, 0xc0, 0x78, 0x07, 0x80, 0x70, 0x07, 0x00, 0x60, 0x06, 0x00, 0x40, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

const uint8_t Home[] =
{
		0x00, 0x18, 0x00, 0x00, 0x3c, 0x00, 0x00, 0x7e, 0x00, 0x00, 0xff, 0x00, 0x01, 0xff, 0x80, 0x03, 0xe7, 0xc0, 0x07, 0xc3, 0xe0, 0x0f, 0x81, 0xf0, 0x1f, 0x00, 0xf8, 0x3e, 0x00, 0x7c, 0x7c, 0x00, 0x3e, 0xdc, 0x00, 0x3b, 0x1c, 0x00, 0x38, 0x1c, 0x00, 0x38, 0x1c, 0x00, 0x38, 0x1c, 0x00, 0x38, 0x1c, 0x00, 0x38, 0x1c, 0x00, 0x38, 0x1c, 0x00, 0x38, 0x1c, 0x00, 0x38, 0x1c, 0x00, 0x38, 0x1f, 0xff, 0xf8, 0x1f, 0xff, 0xf8, 0x1f, 0xff, 0xf8
};
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

// Helper function for UI designs
void LCD_DrawUI(uint16_t x_pos,uint16_t y_pos, const uint8_t LOGO[]){
	LCD_OpenWindow(x_pos, y_pos, 24, 24);
			  int temp;
			  for(int Page = 0; Page < 24; Page++){
				  for(int Column = 0; Column < 24; Column++){
					  int square = 1;
					  if(Column % 8 == 0){
						  temp = LOGO[Page * 3 + Column / 8];
					  }
					  for(int i = 8 * (Column/8 + 1); i > Column + 1; i--){
						  square = square * 2;
					  }
					  if(temp - square >= 0){
						  temp = temp - square;
						  LCD_DrawDot(x_pos + Column, y_pos + Page, BLACK);
					  }
					  else if(temp == 1 && square == 2){
						  LCD_DrawDot(x_pos + Column, y_pos + Page, BLACK);
					  }
				  }
			  }
}

void delay_us(uint16_t us)
{
	//HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_RESET);
	HAL_TIM_Base_Start(&htim6);
	__HAL_TIM_SET_COUNTER(&htim6, 0);
	while((__HAL_TIM_GET_COUNTER(&htim6))< us){
		continue;
	}
}

void Set_Pin_Output(GPIO_TypeDef *Port, uint16_t Pin)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	GPIO_InitStruct.Pin = Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(Port, &GPIO_InitStruct);
}

void Set_Pin_Input(GPIO_TypeDef *Port, uint16_t Pin)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	GPIO_InitStruct.Pin = Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Speed = GPIO_PULLUP;
	HAL_GPIO_Init(Port, &GPIO_InitStruct);
}

uint8_t DHT_Start(void)
{
	Set_Pin_Output(DHT11_PORT, DHT11_PIN);
	HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, 0);
	delay_us(18000);
	HAL_GPIO_WritePin(DHT11_PORT, DHT11_PIN, 1);
	delay_us(20);
	Set_Pin_Input(DHT11_PORT, DHT11_PIN);
	uint8_t status = 0;
	delay_us(40);
	if(!(HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN)))
	{
		delay_us(80);
		if((HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN))){
      status = 1;
    }
		else{
      status = -1;
    }
	}
	//while((HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN)));

	return status;
}

uint8_t DHT11_Read(void)
{
	uint8_t data;
	for(int i = 0; i < 8; i++)
	{
		while(!(HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN)));
		delay_us(40);
		if(!(HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN)))
		{
			data&= ~(1<<(7-i));
		}
		else{
      data|= (1<<(7-i));
    }
	while((HAL_GPIO_ReadPin(DHT11_PORT, DHT11_PIN))){
		continue;
	}
	}
	return data;
}

void UI_Main(void)
{
	LCD_Clear(0, 0, 240, 320, BACKGROUND);
	LCD_DrawString(20, 30,"Weather and News Station");
	LCD_DrawString(20, 45,"MP3 Player");
	LCD_Clear(20, 70, 200, 60, BLUE);
	LCD_DrawString_Color(30, 80,"Room Temperature and ", BLACK, WHITE);
	LCD_DrawString_Color(30, 95,"Humidity ", BLACK, WHITE);
	LCD_Clear(20, 150, 200, 60, GREEN);
	LCD_DrawString_Color(30, 160,"MP3 Player ", BLACK, WHITE);
	LCD_Clear(20, 230, 200, 60, RED);
	LCD_DrawString_Color(30, 240,"News Station ", BLACK, WHITE);
}

void UI_DHT11(void)
{
	LCD_Clear(0, 0, 240, 320, BACKGROUND);
	LCD_Clear(177, 150, 60, 60, RED);
	LCD_DrawUI(194, 170, Home);

}

void UI_MP3(void)
{
	 LCD_Clear(0, 0, 240, 320, BACKGROUND);
	 LCD_Clear(90, 230, 60, 60, BLUE);
	 LCD_DrawUI(107, 250, Pause);		//pause
	 LCD_Clear(20, 230, 60, 60, BLUE);
	 LCD_DrawUI(37, 250, Prev);		//prev
	 LCD_Clear(160, 230, 60, 60, BLUE);
	 LCD_DrawUI(177, 250, Next);		//next
	 LCD_Clear(177, 150, 60, 60, RED);
	 LCD_DrawUI(194, 170, Home);
	 LCD_DrawString(20, 30, "MP3 Player");
}

void UI_News(char *buffer)
{

	LCD_Clear(0, 0, 240, 320, BACKGROUND);
	LCD_Clear(177, 150, 60, 60, RED);
	LCD_DrawUI(194, 170, Home);
	LCD_DrawString(20, 30, "Top News Headline Today");
	/*LCD_DrawString(20, 50, "No roles for Princes Harry or Andrew in King Charles' coronation - CBS News");
	LCD_DrawString(20, 100, "Sixers lose 114-102 to Boston Celtics in Game 3");*/
	LCD_DrawString(20, 50, buffer);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	char http_response_buffer[MAX_BUFFER_SIZE];
	char buffer_print1[MAX_BUFFER_SIZE];
	char buffer_print2[MAX_BUFFER_SIZE];
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM6_Init();
  MX_FSMC_Init();
  MX_USART1_UART_Init();
  MX_USART3_UART_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */
  void Send_to_ESP(const char* command, char *response_buffer,uint16_t response_buffer_size,int delayflag){
	  HAL_UART_Transmit(ESP8266_UART, (uint8_t*)command, strlen(command), 500);
	  if(delayflag == 0){
		  HAL_UART_Receive(ESP8266_UART, (uint8_t*)response_buffer, response_buffer_size-1, 1000);
	  }
	  else if(delayflag == 2){
		  HAL_UART_Receive(ESP8266_UART, (uint8_t*)response_buffer, response_buffer_size-1, 4000);
	  }
	  else if(delayflag == 3){
		  HAL_UART_Receive(ESP8266_UART, (uint8_t*)response_buffer, response_buffer_size-1, 800);
	  }
	  else{
		  HAL_UART_Receive(ESP8266_UART, (uint8_t*)response_buffer, response_buffer_size-1, 4000);
	  }
  }
  void ESP_INIT(){
	  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, SET); //Initialize the ESP8266
	  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, SET); //RST active on logical low.
	  char response[100];
	  bzero(response, sizeof(response));
	  do {
		  Send_to_ESP(AT_COMMAND_CHECK, response, sizeof(response),0);
	  } while (strstr(response, "OK") == NULL);
	  bzero(response, sizeof(response));
	  Send_to_ESP("AT+CWMODE=3\r\n", response, sizeof(response),0);
	  while (strstr(response, "OK") == NULL);
	  bzero(response, sizeof(response));
	  Send_to_ESP(AT_COMMAND_RESET,response,sizeof(response),0);
	  while (strstr(response, "OK") == NULL);
	  bzero(response, sizeof(response));
	  HAL_Delay(1000);
	  HAL_Delay(1000);
	  HAL_Delay(1000);
	  char cm[100];
	  Send_to_ESP("AT+CWDHCP=1,1\r\n", response, sizeof(response),0);
	  while (strstr(response, "OK") == NULL);
	  bzero(response, sizeof(response));
	  Send_to_ESP(AT_COMMAND_SINGLE,response,sizeof(response),0);
	  while (strstr(response, "OK") == NULL);
	  bzero(cm,sizeof(cm));
	  bzero(response, sizeof(response));
	  sprintf(cm,"AT+CWJAP=\"%s\",\"%s\"\r\n",WIFI_SSID,WIFI_PASSWORD);
	  do{
		  bzero(response, sizeof(response));
		  Send_to_ESP(cm, response, sizeof(response),1);
	  }while(strstr(response, "OK") == NULL);
  }

  void TEMP(){
  	  char cm[1024];
  	  bzero(http_response_buffer,sizeof(http_response_buffer));
  	  bzero(buffer_print1,sizeof(buffer_print1));
  	  bzero(cm,sizeof(cm));
  	  Send_to_ESP(AT_COMMAND_SETMODE, http_response_buffer,sizeof(http_response_buffer),0);
  	  while (strstr(http_response_buffer, "OK") == NULL){
  		  HAL_Delay(100);
  	  }
  	  bzero(http_response_buffer, sizeof(http_response_buffer));
  	  sprintf(cm,"AT+CIPSTART=\"TCP\",\"%s\",%s\r\n",TIME_IP,TIME_PORT);
  	  Send_to_ESP(cm,http_response_buffer,sizeof(http_response_buffer),0);
  	  while (strstr(http_response_buffer, "CONNECT") == NULL){
  		  HAL_Delay(100);
  	  }
  	  HAL_Delay(300);
  	  bzero(http_response_buffer, sizeof(http_response_buffer));

  	  Send_to_ESP("AT+CIPSEND\r\n",http_response_buffer,sizeof(http_response_buffer),3);
  	  while (strstr(http_response_buffer, "OK") == NULL){
  		  HAL_Delay(100);
  	  }
  	  bzero(http_response_buffer, sizeof(http_response_buffer));
  	  bzero(cm,sizeof(cm));
  	  Send_to_ESP("GET /api/timezone/Asia/Hong_Kong HTTP/1.1\r\nHost: worldtimeapi.org\r\nUser-Agent: ESP8266\r\n\r\n", http_response_buffer,sizeof(http_response_buffer),2); //Still bad requesting, try reducing the delay.
  	  HAL_Delay(1000);
  	  char temp[2048];
  	  bzero(temp,sizeof(temp));
  	  strcpy(temp,http_response_buffer);
  	  bzero(http_response_buffer, sizeof(http_response_buffer));
  	  Send_to_ESP("AT\r\n", http_response_buffer, sizeof(http_response_buffer),0);
  	  char *datetime_start = strstr(temp, "\"datetime\":\"");
  	  if (datetime_start == NULL) {

  		} else {
  			// Skip the datetime key and colon to get the start of the value
  			datetime_start += strlen("\"datetime\":\"");
  			// Find the end of the datetime value
  			char *datetime_end = strchr(datetime_start, '\"');
  			if (datetime_end == NULL) {

  			} else {
  				// Copy the current time to the output buffer
  				size_t datetime_len = datetime_end - datetime_start;
  				strncpy(buffer_print1, datetime_start, datetime_len);
  				buffer_print1[datetime_len] = '\0';
  			}
  		}
  	  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, RESET); //RST active on logical low.
    }

  void TCP(){
	  char cm[1024];
	  bzero(http_response_buffer,sizeof(http_response_buffer));
	  bzero(buffer_print1,sizeof(buffer_print1));
	  bzero(buffer_print2,sizeof(buffer_print2));
	  bzero(cm,sizeof(cm));
 	  Send_to_ESP(AT_COMMAND_SETMODE, http_response_buffer,sizeof(http_response_buffer),0);
 	  while (strstr(http_response_buffer, "OK") == NULL){
		  HAL_Delay(100);
	  }
 	  bzero(http_response_buffer, sizeof(http_response_buffer));
	  sprintf(cm,"AT+CIPSTART=\"TCP\",\"%s\",%s\r\n",NEWS_IP,NEW_PORT);
	  Send_to_ESP(cm,http_response_buffer,sizeof(http_response_buffer),4);
	  while (strstr(http_response_buffer, "CONNECT") == NULL){
		  HAL_Delay(100);
	  }
	  HAL_Delay(1000);
	  bzero(http_response_buffer, sizeof(http_response_buffer));

	  Send_to_ESP("AT+CIPSEND\r\n",http_response_buffer,sizeof(http_response_buffer),3);
	  while (strstr(http_response_buffer, "OK") == NULL){
		  HAL_Delay(100);
		  Send_to_ESP(cm,http_response_buffer,sizeof(http_response_buffer),0);
		  bzero(http_response_buffer, sizeof(http_response_buffer));
		  Send_to_ESP("AT+CIPSEND\r\n",http_response_buffer,sizeof(http_response_buffer),0);
	  }
	  bzero(http_response_buffer, sizeof(http_response_buffer));
	  bzero(cm,sizeof(cm));
	  int count = 10; //timeout
	  do{
		  Send_to_ESP("GET /data HTTP/1.1\r\nHost: 43.225.10.196:3000\r\n\r\n", http_response_buffer,sizeof(http_response_buffer),2); //Still bad requesting, try reducing the delay.
		  HAL_Delay(1000);
		  count++;
	  }while(strstr(http_response_buffer,"200 OK") == NULL);

	  const char* articles_start = strstr(http_response_buffer, "\"articles\":[");
	  if (articles_start == NULL) {
	          return 1;
	  }
	  articles_start += 12;
	  const char* articles_end = strchr(articles_start, ']');
	  if (articles_end == NULL) {
		  return 1;
	  }
	  const char* article_start = articles_start;
	  const char* article_end = strchr(article_start, ']');
	  if (article_end == NULL || article_end > articles_end) {
		  return 1;
	  }
	  int title_len = (int)(article_end - article_start - 2);
	  strncpy(buffer_print1, article_start + 1, title_len);
	  buffer_print1[title_len] = '\0';
	  Send_to_ESP("AT+CIPCLOSE\r\n", http_response_buffer, sizeof(http_response_buffer),0);
	  HAL_Delay(1000);
	  int current = 0;
	  for(int i=0 ; i<strlen(buffer_print1) ; i++){
		  if(buffer_print1[i] != '\\'){
			  buffer_print2[current] = buffer_print1[i];
			  current++;
		  }
	  }
	  buffer_print2[current] ='\0';
  }
  //ESP_INIT();
  //TCP();
  LCD_INIT();
  LCD_DrawString(0, 0, "INITIALISING>>>");
  DF_Stop();
  HAL_Delay(2000);
  LCD_Clear(0,0,240,320,BACKGROUND);

  while( ! XPT2046_Touch_Calibrate());

  UI_Main();
  ESP_INIT();
  TCP();
  //DF_Init(10);
  //DF_PlayFromStart();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  switch(UI_Page){
	  case 0:
		  if(ucXPT2046_TouchFlag == 1)
		  {
			  ucXPT2046_TouchFlag = 0;
			  UI_Page = Check_maintouchkey();
			  first = UI_Page;
		  }
		  Check_Key ();
		  HAL_Delay(50);
		  break;
	  case 1:
		  if(first != 0){
			  UI_DHT11();
			  first = 0;
		  }

		  //Sensor
		  if(DHT_Start()){
			  hum1 = DHT11_Read();
			  hum2 = DHT11_Read();
			  temp1 = DHT11_Read();
			  temp2 = DHT11_Read();
			  check = DHT11_Read();
		  }
		  char hum[20], temp[20];
		  if(hum1 + hum2 + temp1 + temp2 == check){
			  sprintf(hum, "%d.%d %%", hum1, hum2);
			  sprintf(temp, "%d.%d C", temp1, temp2);
			  LCD_DrawString(32, 10, "Current Room");
			  LCD_DrawString(32, 30,"Humidity:");
			  LCD_DrawString(32, 60,"Temperature:");
			  LCD_DrawString(150, 30, hum);
			  LCD_DrawString(150, 60, temp);
			  //HAL_Delay(250);
			  //LCD_DrawString(200,32,"                ");
			  //LCD_DrawString(200,48,"                ");
		  }

		  HAL_Delay(2000);
		  Check_Key ();
		  if(ucXPT2046_TouchFlag == 1)
		  {
			  ucXPT2046_TouchFlag = 0;
			  UI_Page = Check_DHTouchkey();
			  if(UI_Page == 0){
				  UI_Main();
			  }
		  }
		  break;
	  case 2:
		  if(first != 0){
			  UI_MP3();
			  first = 0;
		  }
		  //Player
		      if(HAL_GPIO_ReadPin(Play_start_port,Play_start_pin) && flaging == 0){
		        while(HAL_GPIO_ReadPin(Play_start_port,Play_start_pin)){
		          continue;
		        }
		        flaging = 1;
		        DF_Init(10);
		        DF_PlayFromStart();
		      }
		      else if (HAL_GPIO_ReadPin(Play_start_port,Play_start_pin) && flaging == 1){
		      	while(HAL_GPIO_ReadPin(Play_start_port,Play_start_pin)){
		      		continue;
		      	}
		      	flaging = 0;
		      	DF_Stop();
		      }
		  	Check_Key ();

		  //TouchScreen
		  	  if(ucXPT2046_TouchFlag == 1)
		  	  {
		  		  UI_Page = Check_touchkey();
		  		  ucXPT2046_TouchFlag = 0;
				  if(UI_Page == 0){
					  UI_Main();
				  }
		  	  }
		  	  HAL_Delay(50);
		  break;
	  case 3://NEWS
		  if(first != 0){
			  UI_News(buffer_print2);
			  first = 0;
		  }
		  //TEMP();
	  	  if(ucXPT2046_TouchFlag == 1)
	  	  {
	  		  UI_Page = Check_NewsTouchkey();
	  		  ucXPT2046_TouchFlag = 0;
			  if(UI_Page == 0){
				  UI_Main();
			  }
	  	  }
	  	  HAL_Delay(50);
	  	  Check_Key ();
		  break;
	  }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM6_Init(void)
{

  /* USER CODE BEGIN TIM6_Init 0 */
	__HAL_RCC_TIM6_CLK_ENABLE();

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 49;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 65534;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, XPT_MOSI_Pin|XPT_CLK_Pin|GPIO_PIN_1, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12|XPT_CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5|GPIO_PIN_8|GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pins : XPT_MOSI_Pin XPT_CLK_Pin */
  GPIO_InitStruct.Pin = XPT_MOSI_Pin|XPT_CLK_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pin : PE3 */
  GPIO_InitStruct.Pin = GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pin : EXTI_Pin */
  GPIO_InitStruct.Pin = EXTI_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(EXTI_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PC13 PC6 */
  GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PA0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PA3 */
  GPIO_InitStruct.Pin = GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PD12 */
  GPIO_InitStruct.Pin = GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pin : XPT_CS_Pin */
  GPIO_InitStruct.Pin = XPT_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(XPT_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PB5 */
  GPIO_InitStruct.Pin = GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PB8 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PE1 */
  GPIO_InitStruct.Pin = GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_IRQn);

}

/* FSMC initialization function */
static void MX_FSMC_Init(void)
{

  /* USER CODE BEGIN FSMC_Init 0 */

  /* USER CODE END FSMC_Init 0 */

  FSMC_NORSRAM_TimingTypeDef Timing = {0};

  /* USER CODE BEGIN FSMC_Init 1 */

  /* USER CODE END FSMC_Init 1 */

  /** Perform the SRAM1 memory initialization sequence
  */
  hsram1.Instance = FSMC_NORSRAM_DEVICE;
  hsram1.Extended = FSMC_NORSRAM_EXTENDED_DEVICE;
  /* hsram1.Init */
  hsram1.Init.NSBank = FSMC_NORSRAM_BANK1;
  hsram1.Init.DataAddressMux = FSMC_DATA_ADDRESS_MUX_DISABLE;
  hsram1.Init.MemoryType = FSMC_MEMORY_TYPE_SRAM;
  hsram1.Init.MemoryDataWidth = FSMC_NORSRAM_MEM_BUS_WIDTH_16;
  hsram1.Init.BurstAccessMode = FSMC_BURST_ACCESS_MODE_DISABLE;
  hsram1.Init.WaitSignalPolarity = FSMC_WAIT_SIGNAL_POLARITY_LOW;
  hsram1.Init.WrapMode = FSMC_WRAP_MODE_DISABLE;
  hsram1.Init.WaitSignalActive = FSMC_WAIT_TIMING_BEFORE_WS;
  hsram1.Init.WriteOperation = FSMC_WRITE_OPERATION_ENABLE;
  hsram1.Init.WaitSignal = FSMC_WAIT_SIGNAL_DISABLE;
  hsram1.Init.ExtendedMode = FSMC_EXTENDED_MODE_DISABLE;
  hsram1.Init.AsynchronousWait = FSMC_ASYNCHRONOUS_WAIT_DISABLE;
  hsram1.Init.WriteBurst = FSMC_WRITE_BURST_DISABLE;
  /* Timing */
  Timing.AddressSetupTime = 15;
  Timing.AddressHoldTime = 15;
  Timing.DataSetupTime = 255;
  Timing.BusTurnAroundDuration = 15;
  Timing.CLKDivision = 16;
  Timing.DataLatency = 17;
  Timing.AccessMode = FSMC_ACCESS_MODE_A;
  /* ExtTiming */

  if (HAL_SRAM_Init(&hsram1, &Timing, NULL) != HAL_OK)
  {
    Error_Handler( );
  }

  /** Disconnect NADV
  */

  __HAL_AFIO_FSMCNADV_DISCONNECTED();

  /* USER CODE BEGIN FSMC_Init 2 */

  /* USER CODE END FSMC_Init 2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
